import static org.junit.Assert.assertEquals;

import javax.crypto.ShortBufferException;

import org.junit.Test;

public class Ex05 {
	// n을 3진법으로 바꾸고 뒤집어서 10진법으로 바꿔서 출력하라
	public static void main(String[] args) {
		for(int i=1;i<16;i++) {
			System.out.print(i + " : " + conversion(i, 2));
			System.out.print(" : " + conversion(i, 3));
			System.out.println(" : " + conversion(i, 16));
		}
		Ex05 ex05 = new Ex05();
		System.out.println(ex05.solution(12));
	}
	@Test
	public void test() {
		Ex05 ex05 = new Ex05();
		assertEquals(ex05.solution(45), 7);
		assertEquals(ex05.solution(125), 229);
	}
	
	public int solution(int n) {
//		int result = 0;
//		// conversion(n, 3) : n을 3집법으로 변경
//		// StringBuffer의 reverse()로 뒤집기
//		// toString()으로 String타입으로 변경
//		// String t = new StringBuffer(conversion(n, 3)).reverse().toString();
//		String t = conversion(n, 3);
//		String tt="";
//		for(char c : t.toCharArray()) tt = c + tt;
//		//System.out.println(t + " : " + tt);
//		result = Integer.parseInt(tt, 3); // String을 정수화한다. 두번째 인수가 진법이다. ==> 3진법 문자를 10진수로 
//		System.out.println(n + " : " + t + " : " + result);
//		return result;
		return Integer.parseInt(new StringBuffer(Integer.toString(n, 3)).reverse().toString(), 3);
	}
	
	// n을 base 진법으로 변환하는 함수
	public static String conversion(int n, int base) {
		String result = "";
		while(n>0) {
			if(n%base<10)
				result = n%base + result;
			else // 11진법 이상일 경우에는 알파벳으로 변경해준다.
				result = (char)((n%base-10) + 'A') + result;
			
			n /= base;
		}
		return result;
	}
}
