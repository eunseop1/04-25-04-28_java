import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Ex03 {
	@Test
	public void test() {
		Ex03 ex03 = new Ex03();
		assertEquals(ex03.solution(new String[] {"Park","Kim"}), "김서방은 1에 있다");
	}
	
	public String solution(String[] seoul) {
		String answer = "";
		for(int i=0;i<seoul.length;i++) {
			if(seoul[i].equals("Kim")) {
				answer = "김서방은 " + i + "에 있다";
				break;
			}
		}
		return answer;
	}
}
